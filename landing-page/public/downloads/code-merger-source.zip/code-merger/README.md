# Code Merger — source development snapshot

One chat for Claude Code, Codex, and OpenCode.
The app runs locally in your browser using your installed, signed-in agent CLIs.

## Start

Requires Node.js 20.9 or newer.
Extract this ZIP and open a terminal in the code-merger folder:

    npm install
    npm run dev

Open http://127.0.0.1:4317. Install and sign in to at least one agent CLI,
then use Recheck in the app to detect it.

For a production build:

    npm run build
    npm start

This is a development snapshot, not a native installer. macOS and Linux use
the same source package. Windows CLI detection has not yet been verified.
The bundle contains no conversations, user workspace files, credentials,
node_modules, build output, or landing-page source.
