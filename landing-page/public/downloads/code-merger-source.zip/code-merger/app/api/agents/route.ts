import { json } from "@/lib/server/http"
import { agentList, DEFAULT_CWD } from "@/lib/server/store"

export async function GET(request: Request) {
  const refresh = new URL(request.url).searchParams.has("refresh")
  return json({ agents: await agentList(refresh), defaultCwd: DEFAULT_CWD })
}
