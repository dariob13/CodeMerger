import { fail, json, readBody } from "@/lib/server/http"
import { DEFAULT_CWD, expandPath, isDir, newId, saveChat, state, summary, type Chat } from "@/lib/server/store"

export async function GET() {
  const chats = [...state.chats.values()].map(summary).sort((a, b) => b.updatedAt - a.updatedAt)
  return json({ chats })
}

export async function POST(request: Request) {
  const body = await readBody(request)
  const cwd = typeof body.cwd === "string" && body.cwd.trim() ? expandPath(body.cwd) : DEFAULT_CWD
  if (!isDir(cwd)) return fail(`Folder not found: ${cwd}`)
  const now = Date.now()
  const chat: Chat = { id: newId(), title: "New chat", cwd, createdAt: now, updatedAt: now, lastAgent: null, sessions: {}, messages: [] }
  state.chats.set(chat.id, chat)
  await saveChat(chat)
  return json({ chat: { ...summary(chat), messages: [] } }, 201)
}
