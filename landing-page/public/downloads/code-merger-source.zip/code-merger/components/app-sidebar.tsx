"use client"

import * as React from "react"
import { PlusIcon, RefreshCwIcon, SquareTerminalIcon, Trash2Icon } from "lucide-react"
import { AgentDot } from "@/components/agent-dot"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuAction,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
  useSidebar,
} from "@/components/ui/sidebar"
import { Spinner } from "@/components/ui/spinner"
import type { ChatsState } from "@/hooks/use-chats"
import type { AgentInfo, ChatSummary } from "@/lib/types"

function ConnectDialog({ agent, onClose }: { agent: AgentInfo | null; onClose: () => void }) {
  return (
    <Dialog open={Boolean(agent)} onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Connect {agent?.name}</DialogTitle>
          <DialogDescription>
            Code Merger uses the {agent?.name} CLI installed on this machine. Run these in a terminal, then press Recheck in the sidebar.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="agent-install">{agent?.install ? "1. Install" : "Command not found"}</Label>
            <Input id="agent-install" readOnly className="font-mono" value={agent?.install || agent?.command || ""} onFocus={(e) => e.target.select()} />
          </div>
          {agent?.login && (
            <div className="grid gap-2">
              <Label htmlFor="agent-login">2. Sign in</Label>
              <Input id="agent-login" readOnly className="font-mono" value={agent.login} onFocus={(e) => e.target.select()} />
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}

export function AppSidebar({ state }: { state: ChatsState }) {
  const { agents, chats, chat, newChat, openChat, deleteChat, recheck } = state
  const { isMobile, setOpenMobile } = useSidebar()
  const [pendingDelete, setPendingDelete] = React.useState<ChatSummary | null>(null)
  const [connecting, setConnecting] = React.useState<AgentInfo | null>(null)
  const [checking, setChecking] = React.useState(false)
  const color = (id: string | null) => agents.find((a) => a.id === id)?.color
  const closeOnMobile = () => isMobile && setOpenMobile(false)

  return (
    <Sidebar>
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <div className="flex items-center gap-2 px-2 py-1.5 font-semibold">
              <SquareTerminalIcon className="size-5" />
              Code Merger
            </div>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton
              variant="outline"
              onClick={() => {
                newChat()
                closeOnMobile()
              }}
            >
              <PlusIcon />
              New chat
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Chats</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {!chats.length && <p className="px-2 py-1 text-sm text-muted-foreground">No chats yet</p>}
              {chats.map((c) => (
                <SidebarMenuItem key={c.id}>
                  <SidebarMenuButton
                    isActive={chat?.id === c.id}
                    onClick={() => {
                      openChat(c.id)
                      closeOnMobile()
                    }}
                  >
                    {c.running ? <Spinner className="size-3" /> : <AgentDot color={color(c.lastAgent)} className="mx-0.5" />}
                    <span>{c.title}</span>
                  </SidebarMenuButton>
                  <SidebarMenuAction showOnHover aria-label={`Delete chat ${c.title}`} onClick={() => setPendingDelete(c)}>
                    <Trash2Icon />
                  </SidebarMenuAction>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarSeparator className="mx-0" />
      <SidebarFooter className="p-0">
        <SidebarGroup>
          <SidebarGroupLabel>Agents</SidebarGroupLabel>
          <SidebarGroupAction
            title="Look for newly installed CLIs"
            aria-label="Recheck agents"
            disabled={checking}
            onClick={async () => {
              setChecking(true)
              await recheck()
              setChecking(false)
            }}
          >
            {checking ? <Spinner /> : <RefreshCwIcon />}
          </SidebarGroupAction>
          <SidebarGroupContent>
            <SidebarMenu>
              {agents.map((a) => (
                <SidebarMenuItem key={a.id}>
                  {a.connected ? (
                    <SidebarMenuButton asChild className="hover:bg-transparent active:bg-transparent">
                      <div title={a.version}>
                        <AgentDot color={a.color} className="mx-0.5" />
                        <span>{a.name}</span>
                      </div>
                    </SidebarMenuButton>
                  ) : (
                    <SidebarMenuButton className="text-muted-foreground" onClick={() => setConnecting(a)}>
                      <AgentDot className="mx-0.5" />
                      <span>{a.name}</span>
                    </SidebarMenuButton>
                  )}
                  <SidebarMenuBadge>
                    <Badge variant={a.connected ? "secondary" : "outline"}>{a.connected ? "Connected" : "Connect"}</Badge>
                  </SidebarMenuBadge>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarFooter>

      <ConnectDialog agent={connecting} onClose={() => setConnecting(null)} />

      <AlertDialog open={Boolean(pendingDelete)} onOpenChange={(open) => !open && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this chat?</AlertDialogTitle>
            <AlertDialogDescription>
              &ldquo;{pendingDelete?.title}&rdquo; will be removed from Code Merger. This can&apos;t be undone. Files the agents created stay
              where they are.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={() => pendingDelete && deleteChat(pendingDelete.id)}>
              Delete chat
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Sidebar>
  )
}
