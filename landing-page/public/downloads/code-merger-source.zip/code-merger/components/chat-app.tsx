"use client"

import * as React from "react"
import { SquareTerminalIcon } from "lucide-react"
import { AppSidebar } from "@/components/app-sidebar"
import { ChatMessage } from "@/components/chat-message"
import { Composer } from "@/components/composer"
import { FolderDialog } from "@/components/folder-dialog"
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { ScrollArea } from "@/components/ui/scroll-area"
import { SidebarInset, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar"
import { useChats } from "@/hooks/use-chats"

export function ChatApp() {
  const state = useChats()
  const { chat, agents, defaultCwd, setFolder } = state
  const bottom = React.useRef<HTMLDivElement>(null)
  const atBottom = React.useRef(true)
  const messages = chat?.messages

  // Follow the reply as it streams, unless the user has scrolled up to read.
  React.useEffect(() => {
    const node = bottom.current
    if (!node) return
    const observer = new IntersectionObserver(([entry]) => (atBottom.current = entry.isIntersecting), { rootMargin: "80px" })
    observer.observe(node)
    return () => observer.disconnect()
  }, [])
  React.useEffect(() => {
    atBottom.current = true
  }, [chat?.id])
  React.useEffect(() => {
    if (atBottom.current) bottom.current?.scrollIntoView({ block: "end" })
  }, [messages])

  React.useEffect(() => {
    document.title = chat ? `${chat.title} · Code Merger` : "Code Merger"
  }, [chat])

  return (
    <SidebarProvider className="h-svh">
      <AppSidebar state={state} />
      <SidebarInset className="h-svh min-w-0 overflow-hidden">
        <header className="flex h-13 shrink-0 items-center gap-2 px-3">
          <SidebarTrigger />
          <h1 className="min-w-0 flex-1 truncate text-sm font-medium">{chat?.title || "New chat"}</h1>
          <FolderDialog cwd={chat?.cwd || defaultCwd} onSave={setFolder} />
        </header>

        <ScrollArea className="min-h-0 flex-1">
          <div className="mx-auto flex min-h-[calc(100svh-11.5rem)] w-full max-w-3xl flex-col gap-6 px-4 pt-2 pb-8">
            {messages?.length ? (
              messages.map((m) => (
                <ChatMessage key={m.id} message={m} agent={m.role === "assistant" ? agents.find((a) => a.id === m.agent) : undefined} />
              ))
            ) : (
              <Empty className="flex-1">
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <SquareTerminalIcon />
                  </EmptyMedia>
                  <EmptyTitle className="text-xl">What are we working on?</EmptyTitle>
                  <EmptyDescription>
                    Pick an agent below and start typing. You can switch agents at any point; the next one is handed the conversation so
                    far.
                  </EmptyDescription>
                </EmptyHeader>
              </Empty>
            )}
            <div ref={bottom} aria-hidden />
          </div>
        </ScrollArea>

        <Composer state={state} />
      </SidebarInset>
    </SidebarProvider>
  )
}
