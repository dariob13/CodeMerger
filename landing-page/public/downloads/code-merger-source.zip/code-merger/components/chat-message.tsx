"use client"

import * as React from "react"
import { CircleAlertIcon } from "lucide-react"
import { AgentDot } from "@/components/agent-dot"
import { Markdown } from "@/components/markdown"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Spinner } from "@/components/ui/spinner"
import type { AgentInfo, Message, ToolPart } from "@/lib/types"

function ToolRow({ tool }: { tool: ToolPart }) {
  return (
    <div className="my-1.5 flex min-w-0 items-center gap-2">
      <Badge variant={tool.status === "error" ? "destructive" : "outline"} className="font-mono">
        {tool.status === "running" && <Spinner data-icon="inline-start" />}
        {tool.name}
      </Badge>
      <span className="truncate font-mono text-xs text-muted-foreground" title={tool.detail}>
        {tool.detail}
      </span>
    </div>
  )
}

export const ChatMessage = React.memo(function ChatMessage({ message, agent }: { message: Message; agent?: AgentInfo }) {
  if (message.role === "user") {
    return (
      <div className="max-w-[82%] self-end rounded-2xl bg-muted px-4 py-2.5 text-[15px] leading-7 wrap-anywhere whitespace-pre-wrap">
        {message.text}
      </div>
    )
  }

  const last = message.parts[message.parts.length - 1]
  const waiting = message.status === "running" && (!last || last.type === "tool")

  return (
    <article className="min-w-0">
      <header className="mb-1.5 flex items-center gap-2 text-sm font-medium">
        <AgentDot color={agent?.color} />
        {agent?.name || message.agent}
        {message.model && <span className="font-normal text-muted-foreground">{message.model}</span>}
      </header>
      {message.parts.map((part, i) =>
        part.type === "text" ? <Markdown key={i} text={part.text} /> : <ToolRow key={part.id} tool={part} />
      )}
      {waiting && <Spinner className="my-2 text-muted-foreground" aria-label="Working" />}
      {message.error && (
        <Alert variant="destructive" className="mt-2">
          <CircleAlertIcon />
          <AlertTitle>{agent?.name || message.agent} couldn&apos;t answer</AlertTitle>
          <AlertDescription className="wrap-anywhere whitespace-pre-wrap">{message.error}</AlertDescription>
        </Alert>
      )}
      {message.status === "stopped" && <p className="mt-1.5 text-xs text-muted-foreground">Stopped</p>}
    </article>
  )
})
