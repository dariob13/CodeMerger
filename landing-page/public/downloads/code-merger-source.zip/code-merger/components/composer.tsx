"use client"

import * as React from "react"
import { ArrowUpIcon, SquareIcon } from "lucide-react"
import { AgentDot } from "@/components/agent-dot"
import { InputGroup, InputGroupAddon, InputGroupButton, InputGroupTextarea } from "@/components/ui/input-group"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import type { ChatsState } from "@/hooks/use-chats"
import type { Access } from "@/lib/types"

const ACCESS: Record<Access, { label: string; hint: string }> = {
  read: { label: "Read-only", hint: "Can read the folder and answer, but not change anything." },
  edit: { label: "Can edit files", hint: "Can create and edit files in the working folder." },
  full: { label: "Full access", hint: "Can edit files and run any command without asking." },
}
const DEFAULT_MODEL = "default" // Select items can't have an empty value

export function Composer({ state }: { state: ChatsState }) {
  const { agent, connected, pick, running, setPick, send, stop } = state
  const [text, setText] = React.useState("")
  const input = React.useRef<HTMLTextAreaElement>(null)

  const model = agent && agent.models.some(([value]) => value === pick.models[agent.id]) ? pick.models[agent.id] : ""
  const access: Access = agent?.access.includes(pick.access) ? pick.access : "read"

  const submit = async () => {
    const value = text.trim()
    if (!value || !agent || running) return
    setText("")
    if (!(await send(value, { model, access }))) setText(value)
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-4">
      <InputGroup className="rounded-2xl bg-background shadow-sm dark:bg-input/30">
        <InputGroupTextarea
          ref={input}
          value={text}
          rows={1}
          autoFocus
          disabled={!agent}
          aria-label="Message"
          placeholder={agent ? `Message ${agent.name}…` : "Connect an agent to start chatting"}
          className="max-h-60 min-h-12 px-4 pt-3.5 text-[15px] md:text-[15px]"
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
              e.preventDefault()
              submit()
            }
          }}
        />
        <InputGroupAddon align="block-end" className="flex-wrap text-foreground">
          {connected.length ? (
            <ToggleGroup
              type="single"
              size="sm"
              variant="outline"
              spacing={1}
              aria-label="Agent"
              value={agent?.id}
              onValueChange={(id) => {
                if (!id) return
                setPick({ agent: id })
                input.current?.focus()
              }}
            >
              {connected.map((a) => (
                <ToggleGroupItem key={a.id} value={a.id} aria-label={`${a.name} by ${a.vendor}`}>
                  <AgentDot color={a.color} />
                  {a.short}
                </ToggleGroupItem>
              ))}
            </ToggleGroup>
          ) : (
            <span className="px-1 text-sm">No agents connected. See Agents in the sidebar.</span>
          )}

          {agent && agent.models.length > 1 && (
            <Select
              value={model || DEFAULT_MODEL}
              onValueChange={(value) => setPick({ models: { ...pick.models, [agent.id]: value === DEFAULT_MODEL ? "" : value } })}
            >
              <SelectTrigger size="sm" aria-label="Model" className="border-transparent bg-transparent shadow-none dark:bg-transparent">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {agent.models.map(([value, label]) => (
                    <SelectItem key={value} value={value || DEFAULT_MODEL}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          )}

          {agent && (
            <Select value={access} onValueChange={(value) => setPick({ access: value as Access })}>
              <SelectTrigger
                size="sm"
                aria-label="What the agent may do"
                className="border-transparent bg-transparent shadow-none data-[access=full]:text-destructive dark:bg-transparent"
                data-access={access}
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {agent.access.map((level) => (
                    <SelectItem key={level} value={level} title={ACCESS[level].hint}>
                      {ACCESS[level].label}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          )}

          <Tooltip>
            <TooltipTrigger asChild>
              {running ? (
                <InputGroupButton variant="default" size="icon-sm" className="ml-auto rounded-full" aria-label="Stop" onClick={stop}>
                  <SquareIcon className="fill-current" />
                </InputGroupButton>
              ) : (
                <InputGroupButton
                  variant="default"
                  size="icon-sm"
                  aria-label="Send"
                  // aria-disabled, because a disabled control would dim the whole input group
                  aria-disabled={!agent || !text.trim()}
                  className="ml-auto rounded-full aria-disabled:cursor-default aria-disabled:opacity-40"
                  onClick={submit}
                >
                  <ArrowUpIcon />
                </InputGroupButton>
              )}
            </TooltipTrigger>
            <TooltipContent>{running ? "Stop" : "Send"}</TooltipContent>
          </Tooltip>
        </InputGroupAddon>
      </InputGroup>
    </div>
  )
}
