"use client"

import * as React from "react"
import { FolderIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

// The folder the agents in this chat read and run from.
export function FolderDialog({ cwd, onSave }: { cwd: string; onSave: (cwd: string) => Promise<string | null> }) {
  const [open, setOpen] = React.useState(false)
  const [value, setValue] = React.useState(cwd)
  const [error, setError] = React.useState<string | null>(null)
  const [saving, setSaving] = React.useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!value.trim()) return
    setSaving(true)
    const problem = await onSave(value.trim())
    setSaving(false)
    setError(problem)
    if (!problem) setOpen(false)
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next)
        if (next) {
          setValue(cwd)
          setError(null)
        }
      }}
    >
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="max-w-[45%] rounded-full font-normal text-muted-foreground" title={`Working folder: ${cwd}`}>
          <FolderIcon data-icon="inline-start" />
          <span className="truncate [direction:rtl]">&lrm;{cwd}</span>
        </Button>
      </DialogTrigger>
      <DialogContent>
        <form onSubmit={submit} className="contents">
          <DialogHeader>
            <DialogTitle>Working folder</DialogTitle>
            <DialogDescription>
              Agents in this chat read and run from this folder. Changing it starts each agent&apos;s session fresh; the conversation is
              handed over as text.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-2">
            <Label htmlFor="folder-path">Folder path</Label>
            <Input
              id="folder-path"
              value={value}
              spellCheck={false}
              autoComplete="off"
              placeholder="~/Projects/my-app"
              className="font-mono"
              aria-invalid={Boolean(error)}
              aria-describedby={error ? "folder-error" : undefined}
              onChange={(e) => setValue(e.target.value)}
            />
            {error && (
              <p id="folder-error" className="text-sm text-destructive">
                {error}
              </p>
            )}
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving || !value.trim()}>
              Save
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
