// Shapes shared by the server (lib/server) and the interface (components).

export type Access = "read" | "edit" | "full"
export type ToolStatus = "running" | "done" | "error"

export type TextPart = { type: "text"; text: string }
export type ToolPart = { type: "tool"; id: string; name: string; detail: string; status: ToolStatus }
export type Part = TextPart | ToolPart

// A file the user added to a message. It is stored on disk and agents are pointed at its path.
export type Attachment = { id: string; name: string; type: string; size: number; path: string }

export type UserMessage = { id: string; role: "user"; text: string; attachments?: Attachment[]; ts: number }
export type AssistantMessage = {
  id: string
  role: "assistant"
  agent: string
  model: string
  parts: Part[]
  status: "running" | "done" | "error" | "stopped"
  error?: string
  ts: number
}
export type Message = UserMessage | AssistantMessage

export type ChatSummary = {
  id: string
  title: string
  cwd: string
  updatedAt: number
  lastAgent: string | null
  running: boolean
}
export type ChatDetail = ChatSummary & { messages: Message[] }

export type AgentInfo = {
  id: string
  name: string
  short: string
  vendor: string
  color: string
  command: string
  install: string
  login: string
  models: [value: string, label: string][]
  efforts: [value: string, label: string][]
  access: Access[]
  connected: boolean // its CLI is installed
  auth: AuthState
  authDetail: string
  version: string
}

// Whether the CLI is signed in: "unknown" when the CLI has no way to ask.
export type AuthState = "ok" | "none" | "unknown"

export const isImage = (file: { type: string }) => /^image\/(png|jpeg|gif|webp)$/.test(file.type)

// Normalized output of every agent CLI, and what the events stream carries to the browser.
export type AgentEvent =
  | { type: "text"; delta: string }
  | { type: "tool"; tool: Partial<ToolPart> & { id: string } }
  | { type: "error"; message: string }

export type StreamEvent =
  | AgentEvent
  | { type: "snapshot"; message: AssistantMessage }
  | { type: "done"; message: AssistantMessage; chat: ChatSummary }
  | { type: "idle" }

export function applyEvent(message: AssistantMessage, ev: StreamEvent) {
  if (ev.type === "text") {
    const last = message.parts[message.parts.length - 1]
    if (last && last.type === "text") last.text += ev.delta
    else message.parts.push({ type: "text", text: ev.delta })
  } else if (ev.type === "tool") {
    const given = Object.fromEntries(Object.entries(ev.tool).filter(([, v]) => v !== undefined && v !== ""))
    const existing = message.parts.find((p) => p.type === "tool" && p.id === ev.tool.id)
    if (existing) Object.assign(existing, given)
    else message.parts.push({ type: "tool", name: "Tool", detail: "", status: "running", ...ev.tool })
  } else if (ev.type === "error") {
    message.error = ev.message
  }
}
